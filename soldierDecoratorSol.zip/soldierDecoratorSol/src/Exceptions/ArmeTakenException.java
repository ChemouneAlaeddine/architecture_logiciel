package Exceptions;

public class ArmeTakenException extends Exception {

	public ArmeTakenException() {
		System.out.println("Arme deja prise !\n");
	}
}
