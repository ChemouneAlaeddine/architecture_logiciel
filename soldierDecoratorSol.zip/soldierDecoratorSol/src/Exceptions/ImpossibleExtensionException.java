package Exceptions;

public class ImpossibleExtensionException extends Exception {
	
	public ImpossibleExtensionException() {
		System.out.println("Extension impossible !\n");
	}
}
