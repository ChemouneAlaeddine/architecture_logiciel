package Exceptions;

public class AbsenceArmeException extends Exception {
	public AbsenceArmeException() {
		System.out.println("Arme absente !\n");
	}
}
