package soldier.core;

public class InfantaryMan extends UnitSimple {
	
	public InfantaryMan() {
		super(new ConstBehavior(3, 7, 10, "Arthur"));
	}
}
